## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

## Password Masking
Password masking is only available on the console for Eclipse.
Else, Visual Studio works as well.